$("#simpan").click(function () {
  var npm = $("#npm").val();
  var nama = $("#nama").val();
  var tanggal = $("#tanggal").val();
  var jurusan = $("#jurusan").val();
  var alamat = $("#alamat").val();
});

// Mencari elemen form dan tabel
var form = document.getElementById("form-data");
var tabel = document.getElementById("tabel-data");

// Menangani event submit pada form
form.addEventListener("submit", function (event) {
  event.preventDefault(); // Mencegah form untuk melakukan submit secara default

  // Mengambil nilai dari input npm, nama, jurusan, tanggal lahir, alamat
  var npm = document.getElementById("npm").value;
  var nama = document.getElementById("nama").value;
  var jurusan = document.getElementById("jurusan").value;
  var tanggal = document.getElementById("tanggal").value;
  var alamat = document.getElementById("alamat").value;

  // Memastikan nilai input tidak kosong
  if (npm == "") {
    $("#isi-npm").text("NPM tidak boleh kosong");
    document.getElementById("npm").value = "";
    return;
  } else {
    $("#isi-npm").text("");
  }
  if (nama == "") {
    $("#isi-nama").text("NAMA tidak boleh kosong");
    document.getElementById("nama").value = "";
    return;
  } else {
    $("#isi-nama").text("");
  }
  if (tanggal == "") {
    $("#isi-tanggal").text("Tanggal tidak boleh kosong");
    document.getElementById("tanggal").value = "";
    return;
  } else {
    $("#isi-tanggal").text("");
  }if (jurusan == "") {
    $("#isi-jurusan").text("Jurusan tidak boleh kosong");
    document.getElementById("jurusan").value = "";
    return;
  } else {
    $("#isi-jurusan").text("");
  }
  if (alamat == "") {
    $("#isi-alamat").text("Alamat tidak boleh kosong");
    document.getElementById("alamat").value = "";
    return;
  } else {
    $("#isi-alamat").text("");
  }
  // if (npm != "" && nama_mahasiswa != "" && jurusan != "" && tanggal_lahir != "" && alamat != "") {
  //   $("#alert_berhasil").html(`
  //     <div class="alert alert-success alert-dismissible fade show" role="alert">
  //       <strong>Berhasil Disimpan!</strong> Data berhasil ditambahkan.
  //       <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  //     </div>`);
  //     return;
  // }
  

  // Membuat sebuah baris pada tabel dan menambahkan data ke dalam baris tersebut
  var row = tabel.insertRow(-1);
  var cell1 = row.insertCell(0);
  var cell2 = row.insertCell(1);
  var cell3 = row.insertCell(2);
  var cell4 = row.insertCell(3);
  var cell5 = row.insertCell(4);
  cell1.innerHTML = npm;
  cell2.innerHTML = nama;
  cell3.innerHTML = jurusan;
  cell4.innerHTML = tanggal;
  cell5.innerHTML = alamat;

  // Membersihkan nilai dari input npm, nama, tanggal, alamat, jurusan
  document.getElementById("npm").value = "";
  document.getElementById("nama").value = "";
  document.getElementById("jurusan").value = "";
  document.getElementById("tanggal").value = "";
  document.getElementById("alamat").value = "";
});
